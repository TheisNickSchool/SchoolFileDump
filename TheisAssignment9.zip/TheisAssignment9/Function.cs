using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using System.Dynamic;
using Amazon.Lambda.Core;
using Newtonsoft.Json;
using System.Net.Http;
using System.Web;




// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace TheisAssignment9
{
    public class Function
    {
        public static readonly HttpClient client = new HttpClient();
        public async Task<ExpandoObject> FunctionHandler(string input, ILambdaContext context)
        { 
            dynamic p = new ExpandoObject();
            try
            { //string g = "https://api.nytimes.com/svc/books/v3/lists/current/hardcover-fiction.json?api-key=bAS27Xtyv8UxRhSdTAnuX3qaGUtUm4HP";
               
                HttpResponseMessage response = await client.GetAsync("https://api.nytimes.com/svc/books/v3/lists/current/hardcover-fiction.json?api-key=bAS27Xtyv8UxRhSdTAnuX3qaGUtUm4HP");
                response.EnsureSuccessStatusCode();
                p.book = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<ExpandoObject>(p.book);
            }
            catch (Exception e) {
                p.text = "error happened";
                
                return JsonConvert.DeserializeObject<ExpandoObject>(p.text);
             }
        }
    }
}
