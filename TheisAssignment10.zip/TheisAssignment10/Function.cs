using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Amazon.Lambda.Core;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace TheisAssignment10
{
    public enum Condition { EXCELLENT, GOOD, FAIR, BAD }
    public class Car
    {
        public string Make;
        private int speed;
        public int Speed { 
            get { return speed; }
            set
            {
                if (200<value) {speed = 200; Console.WriteLine("Here");}
                else if (-50>value) { speed = -50; }
                else { speed = value; }
            } 
        }
        public Condition condition;
        public Car(string ma, Condition con)
        {
            Make = ma;
            Speed = 0;
            condition = con;
        }
        public Condition GetCondition() { return condition; }
        public class Function
        {
            public Car FunctionHandler(string input, ILambdaContext context)
            {
                Car car = new Car("Chevy", Condition.EXCELLENT) { };
                return car;
            }
        }
    }
}
