using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Amazon.Lambda.APIGatewayEvents;
using Amazon.Lambda.Core;
using Newtonsoft.Json;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.Lambda.DynamoDBEvents;

// Assembly attribute to enable the Lambda function's JSON input to be converted into a .NET class.
[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

namespace TheisAssignment7
{
    public class Product
    {
public string type;
        public int count;
        public double averageRating;
    }
   
    public class Function
    {

        private static AmazonDynamoDBClient client = new AmazonDynamoDBClient();


        public async Task<List<Product>> FunctionHandler(DynamoDBEvent input, ILambdaContext context)
        {
            Table inventory = Table.LoadTable(client, "RatingsByType");
            
            List<Product> inser = new List<Product>();
            List<DynamoDBEvent.DynamodbStreamRecord> records = (List<DynamoDBEvent.DynamodbStreamRecord>)input.Records;
            if (records.Count > 0)
            {
                DynamoDBEvent.DynamodbStreamRecord record = records[0];
                if (record.EventName.Equals("INSERT"))
                {   
                    
                    Document mydoc = Document.FromAttributeMap(record.Dynamodb.NewImage);
                    Product products = JsonConvert.DeserializeObject<Product>(mydoc.ToJson());
        
                    var request = new UpdateItemRequest
                    {
                        TableName = "RatingByType",
                        Key = new Dictionary<string, AttributeValue>
                        {
                            { "type", new AttributeValue { S = products.type } }
                        },
                        AttributeUpdates = new Dictionary<string, AttributeValueUpdate>()
                        {
                            {
                                "count",
                                new AttributeValueUpdate { Action = "ADD", Value = new AttributeValue { N = "1" } }
                            },
                            {
                                "averageRating",
                                new AttributeValueUpdate{ Action="ADD",Value=new AttributeValue{N="3" } }
                            },//still working out how to get items from the database to work on
                        },
                    };
                    await client.UpdateItemAsync(request);

                }

            }
            return inser;
        }
    }

}

